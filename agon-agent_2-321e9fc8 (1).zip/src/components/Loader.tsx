import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Crown } from 'lucide-react';

/** Cinematic boot screen: crown, wordmark, eased 0-100 counter + gold bar. */
export default function Loader() {
  const [pct, setPct] = useState(0);

  useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const DUR = 1900;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / DUR);
      const eased = 1 - Math.pow(1 - p, 3);
      setPct(Math.round(eased * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <motion.div
      exit={{ opacity: 0, scale: 1.04 }}
      transition={{ duration: 0.55, ease: 'easeInOut' }}
      className="fixed inset-0 z-[90] flex flex-col items-center justify-center bg-ink"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="flex flex-col items-center"
      >
        <Crown className="mb-5 h-10 w-10 text-gold" strokeWidth={1.5} />
        <div className="font-display text-2xl uppercase tracking-[0.35em] text-cream md:text-3xl">
          Monarch
        </div>
      </motion.div>

      <div className="mt-9 flex w-56 flex-col items-center">
        <div className="gold-text font-display text-5xl font-bold tabular-nums">{pct}</div>
        <div className="mt-4 h-px w-full overflow-hidden bg-gold/15">
          <div className="h-full bg-gold" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="mt-5 text-[10px] uppercase tracking-[0.35em] text-gold/50"
      >
        summoning the empire
      </motion.div>
    </motion.div>
  );
}
