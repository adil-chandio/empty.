import { useEffect, useRef, useState } from 'react';
import { gsap } from '../lib/gsap';

/**
 * Custom cursor: gold dot + lagging ring (mix-blend-difference).
 * Over [data-cursor="view"] targets the ring expands and shows a VIEW label.
 * Only enabled on fine-pointer devices.
 */
export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement | null>(null);
  const ringRef = useRef<HTMLDivElement | null>(null);
  const labelRef = useRef<HTMLSpanElement | null>(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)').matches;
    if (!fine) return;
    setEnabled(true);
    document.documentElement.classList.add('custom-cursor');
    return () => {
      document.documentElement.classList.remove('custom-cursor');
    };
  }, []);

  useEffect(() => {
    if (!enabled) return;
    const dot = dotRef.current;
    const ring = ringRef.current;
    const label = labelRef.current;
    if (!dot || !ring || !label) return;

    gsap.set([dot, ring], { x: -100, y: -100 });

    const dotX = gsap.quickTo(dot, 'x', { duration: 0.08, ease: 'power3.out' });
    const dotY = gsap.quickTo(dot, 'y', { duration: 0.08, ease: 'power3.out' });
    const ringX = gsap.quickTo(ring, 'x', { duration: 0.4, ease: 'power3.out' });
    const ringY = gsap.quickTo(ring, 'y', { duration: 0.4, ease: 'power3.out' });

    const onMove = (e: MouseEvent) => {
      dotX(e.clientX);
      dotY(e.clientY);
      ringX(e.clientX);
      ringY(e.clientY);
    };

    const onOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const viewTarget = target?.closest('[data-cursor="view"]');
      const interactive = target?.closest('a, button, [data-cursor]');
      gsap.to(ring, {
        scale: viewTarget ? 2.8 : interactive ? 1.9 : 1,
        duration: 0.35,
        ease: 'power3.out',
      });
      gsap.to(dot, { scale: viewTarget ? 0 : interactive ? 0.35 : 1, duration: 0.35, ease: 'power3.out' });
      gsap.to(label, { opacity: viewTarget ? 1 : 0, duration: 0.25 });
    };

    window.addEventListener('mousemove', onMove, { passive: true });
    window.addEventListener('mouseover', onOver, { passive: true });
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseover', onOver);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <>
      <div
        ref={ringRef}
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[100] -ml-[18px] -mt-[18px] flex h-9 w-9 items-center justify-center rounded-full border border-gold mix-blend-difference"
      >
        <span
          ref={labelRef}
          className="text-[7px] font-bold uppercase tracking-[0.25em] text-gold-light opacity-0"
        >
          view
        </span>
      </div>
      <div
        ref={dotRef}
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[100] -ml-[3px] -mt-[3px] h-1.5 w-1.5 rounded-full bg-gold mix-blend-difference"
      />
    </>
  );
}
