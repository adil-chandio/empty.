import { Fragment, useRef } from 'react';
import { gsap } from '../lib/gsap';
import { useGSAP } from '@gsap/react';
import type { ManifestoLine } from '../lib/types';

interface ManifestoProps {
  lines: ManifestoLine[];
  alias: string;
}

/** Scroll-scrubbed word-by-word reveal — the kingdom's philosophy. */
export default function Manifesto({ lines, alias }: ManifestoProps) {
  const scopeRef = useRef<HTMLElement | null>(null);

  useGSAP(
    () => {
      const words = scopeRef.current?.querySelectorAll('.m-word');
      if (!words || words.length === 0) return;
      gsap.fromTo(
        words,
        { opacity: 0.1 },
        {
          opacity: 1,
          stagger: 0.05,
          ease: 'none',
          scrollTrigger: {
            trigger: scopeRef.current,
            start: 'top 72%',
            end: 'bottom 45%',
            scrub: 0.5,
          },
        }
      );
    },
    { scope: scopeRef }
  );

  return (
    <section ref={scopeRef} className="relative z-10 bg-ink px-6 py-28 md:py-44">
      <div className="mx-auto max-w-5xl">
        <div className="mb-10 flex items-center gap-4 text-[10px] uppercase tracking-[0.45em] text-gold/60 md:mb-14">
          <span className="h-px w-10 bg-gold/40" />
          the philosophy
        </div>

        <p className="text-2xl leading-[1.55] text-cream md:text-5xl md:leading-[1.45]">
          {lines.map((line) => (
            <Fragment key={line.id}>
              {line.text.split(' ').map((word, j) => (
                <span
                  key={j}
                  className={`m-word inline-block ${line.highlighted ? 'gold-text font-display' : ''}`}
                >
                  {word}
                  {'\u00A0'}
                </span>
              ))}
            </Fragment>
          ))}
        </p>

        <div className="mt-10 text-right font-display text-xs uppercase tracking-[0.35em] text-gold/50 md:mt-14 md:text-sm">
          — {alias}
        </div>
      </div>
    </section>
  );
}
