import { Component } from 'react';
import type { ReactNode } from 'react';

interface Props {
  children: ReactNode;
}
interface State {
  error: Error | null;
}

/** Catches render crashes and shows a royal error screen instead of a blank page. */
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error) {
    console.error('Render error:', error);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="fixed inset-0 z-[95] flex flex-col items-center justify-center gap-5 bg-[#060504] px-6 text-center text-[#f4efe4]">
          <div className="font-display text-2xl uppercase tracking-[0.3em]">Monarch</div>
          <p className="max-w-md text-[11px] uppercase tracking-[0.25em] text-[#f4efe4]/50">
            a glitch in the kingdom — {this.state.error.message}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="mt-2 border border-[#d4af37]/50 px-9 py-3 text-[11px] uppercase tracking-[0.3em] text-[#d4af37] transition-colors hover:bg-[#d4af37] hover:text-[#060504]"
          >
            reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
