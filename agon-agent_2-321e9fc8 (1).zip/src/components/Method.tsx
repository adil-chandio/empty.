import { motion } from 'motion/react';
import type { BrandHero, MethodStep, Service } from '../lib/types';

interface MethodProps {
  steps: MethodStep[];
  services: Service[];
  brand: BrandHero;
}

/** The Monarch Method — 4 conquest steps + reverse outline marquee. */
export default function Method({ steps, services, brand }: MethodProps) {
  const base = [...services.map((s) => s.title), brand.brand, brand.alias, 'est. the empire'];
  const seq = [...base, ...base, ...base, ...base];

  return (
    <section className="relative z-10 bg-ink pb-0 pt-24 md:pt-36">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-12 md:mb-16"
        >
          <div className="mb-4 text-[10px] uppercase tracking-[0.45em] text-gold/60">
            the monarch method
          </div>
          <h2 className="font-display text-3xl uppercase tracking-wide text-cream md:text-5xl">
            How The Empire <span className="gold-text">Expands</span>
          </h2>
        </motion.div>

        <div>
          {steps.map((step, i) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, y: 44 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-70px' }}
              transition={{ duration: 0.75, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
              data-cursor
              className="group grid grid-cols-[auto_1fr] items-start gap-5 border-t border-gold/15 py-8 md:gap-12 md:py-12"
            >
              <div className="step-num font-display text-5xl font-bold leading-none md:text-8xl">
                {String(i + 1).padStart(2, '0')}
              </div>
              <div className="pt-1 md:pt-3">
                <h3 className="mb-3 font-display text-lg uppercase tracking-wide text-cream md:text-3xl">
                  {step.title}
                </h3>
                <p className="max-w-2xl text-xs leading-relaxed text-cream/50 md:text-sm">
                  {step.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* reverse outline marquee leading into the case files */}
      <div className="mt-16 overflow-hidden border-y border-gold/20 py-4 md:mt-24 md:py-5">
        <div className="marquee-track-reverse flex w-max items-center">
          {seq.map((t, i) => (
            <span key={i} className="flex items-center whitespace-nowrap">
              <span className="text-outline-strong px-8 font-display text-2xl uppercase tracking-[0.15em] md:text-4xl">
                {t}
              </span>
              <span className="text-xl text-gold/60">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
