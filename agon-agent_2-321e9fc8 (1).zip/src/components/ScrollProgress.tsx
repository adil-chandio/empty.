import { useRef } from 'react';
import { gsap } from '../lib/gsap';
import { useGSAP } from '@gsap/react';

/** Thin gold bar at the very top — scales with total scroll progress. */
export default function ScrollProgress() {
  const barRef = useRef<HTMLDivElement | null>(null);

  useGSAP(() => {
    gsap.to(barRef.current, {
      scaleX: 1,
      ease: 'none',
      scrollTrigger: { start: 0, end: 'max', scrub: 0.4 },
    });
  });

  return (
    <div
      ref={barRef}
      className="fixed left-0 top-0 z-[80] h-[3px] w-full origin-left scale-x-0 bg-gradient-to-r from-gold-deep via-gold to-gold-light"
    />
  );
}
