import { motion } from 'motion/react';
import type { AboutContentRow, AboutFact } from '../lib/types';

interface AboutProps {
  content: AboutContentRow[];
  facts: AboutFact[];
}

const EASE = [0.22, 1, 0.36, 1] as const;

/** The man behind the crown — name, story, quote and the royal fact sheet. */
export default function About({ content, facts }: AboutProps) {
  const get = (key: string) => content.find((c) => c.ckey === key)?.body ?? '';
  const eyebrow = get('eyebrow');
  const title = get('title');
  const quote = get('quote');
  const paragraphs = content
    .filter((c) => c.ckey.startsWith('paragraph'))
    .sort((a, b) => a.id - b.id);

  const words = title.split(' ');
  const last = words.length > 1 ? words.pop() : '';

  return (
    <section className="relative z-10 bg-ink px-6 py-24 md:px-16 md:py-36">
      <div className="mx-auto grid max-w-6xl gap-12 md:grid-cols-2 md:gap-16">
        {/* left — name + quote */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: EASE }}
            className="mb-6 flex items-center gap-4 text-[10px] uppercase tracking-[0.45em] text-gold/60"
          >
            <span className="h-px w-10 bg-gold/40" />
            {eyebrow}
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 34 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8, ease: EASE }}
            className="font-display text-5xl uppercase leading-[1.04] text-cream md:text-7xl"
          >
            {words.length > 0 ? `${words.join(' ')} ` : ''}
            <span className="gold-text">{last || title}</span>
          </motion.h2>

          {quote && (
            <motion.blockquote
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.7, delay: 0.15, ease: EASE }}
              className="mt-10 border-l-2 border-gold/60 pl-5 font-display text-base leading-relaxed text-gold-light/90 md:text-xl"
            >
              “{quote}”
            </motion.blockquote>
          )}
        </div>

        {/* right — story + fact sheet */}
        <div className="flex flex-col justify-center">
          {paragraphs.map((p, i) => (
            <motion.p
              key={p.id}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.7, delay: i * 0.1, ease: EASE }}
              className={`text-sm leading-relaxed text-cream/60 md:text-base ${i > 0 ? 'mt-5' : ''}`}
            >
              {p.body}
            </motion.p>
          ))}

          <motion.dl
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7, delay: 0.2, ease: EASE }}
            className="mt-10"
          >
            {facts.map((f) => (
              <div
                key={f.id}
                className="flex items-baseline justify-between gap-6 border-t border-gold/15 py-3.5 last:border-b"
              >
                <dt className="shrink-0 text-[10px] uppercase tracking-[0.3em] text-gold/60">
                  {f.label}
                </dt>
                <dd className="text-right text-[11px] uppercase tracking-[0.15em] text-cream/80">
                  {f.value}
                </dd>
              </div>
            ))}
          </motion.dl>
        </div>
      </div>
    </section>
  );
}
