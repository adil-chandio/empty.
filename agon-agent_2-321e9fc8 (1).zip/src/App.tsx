import { useCallback, useEffect, useRef, useState } from 'react';
import { gsap } from './lib/gsap';
import { useGSAP } from '@gsap/react';
import { AnimatePresence } from 'motion/react';
import CustomCursor from './components/CustomCursor';
import ScrollProgress from './components/ScrollProgress';
import Loader from './components/Loader';
import Hero from './components/Hero';
import Ticker from './components/Ticker';
import Manifesto from './components/Manifesto';
import About from './components/About';
import Stats from './components/Stats';
import Services from './components/Services';
import Method from './components/Method';
import Gallery from './components/Gallery';
import Outro from './components/Outro';
import {
  fetchAbout,
  fetchBrand,
  fetchGallery,
  fetchManifesto,
  fetchMethod,
  fetchServices,
  fetchStats,
  fetchTicker,
} from './lib/api';
import type {
  AboutContentRow,
  AboutFact,
  BrandHero,
  GalleryItem,
  ManifestoLine,
  MethodStep,
  Service,
  Stat,
  TickerItem,
} from './lib/types';

export default function App() {
  const [brand, setBrand] = useState<BrandHero | null>(null);
  const [stats, setStats] = useState<Stat[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [ticker, setTicker] = useState<TickerItem[]>([]);
  const [manifesto, setManifesto] = useState<ManifestoLine[]>([]);
  const [steps, setSteps] = useState<MethodStep[]>([]);
  const [aboutContent, setAboutContent] = useState<AboutContentRow[]>([]);
  const [aboutFacts, setAboutFacts] = useState<AboutFact[]>([]);
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [outroVisible, setOutroVisible] = useState(false);
  const [outroActive, setOutroActive] = useState(false);

  const rootRef = useRef<HTMLDivElement | null>(null);
  const gallerySectionRef = useRef<HTMLElement | null>(null);
  const outroRef = useRef<HTMLDivElement | null>(null);

  // start each visit at the top of the experience
  useEffect(() => {
    if ('scrollRestoration' in window.history) window.history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);
  }, []);

  // cinematic minimum boot time so the preloader always completes its count
  useEffect(() => {
    const t = window.setTimeout(() => setBooted(true), 2200);
    return () => window.clearTimeout(t);
  }, []);

  // responsive layout switch
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 767px)');
    const update = () => setIsMobile(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  // load everything with auto-retry (survives cold starts / transient API errors)
  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    let lastError: unknown = null;

    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const [b, s, sv, t, m, ms, a, g] = await Promise.all([
          fetchBrand(),
          fetchStats(),
          fetchServices(),
          fetchTicker(),
          fetchManifesto(),
          fetchMethod(),
          fetchAbout(),
          fetchGallery(),
        ]);
        setBrand(b);
        setStats(s);
        setServices(sv);
        setTicker(t);
        setManifesto(m);
        setSteps(ms);
        setAboutContent(a.content);
        setAboutFacts(a.facts);
        setItems(g);
        setLoading(false);
        return;
      } catch (e) {
        lastError = e;
        await new Promise((r) => window.setTimeout(r, 900));
      }
    }

    setError(lastError instanceof Error ? lastError.message : 'something went wrong');
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const dataReady =
    !loading &&
    !error &&
    !!brand &&
    items.length > 0 &&
    stats.length > 0 &&
    services.length > 0 &&
    ticker.length > 0 &&
    manifesto.length > 0 &&
    steps.length > 0 &&
    aboutContent.length > 0 &&
    aboutFacts.length > 0;

  const showLoader = !error && (loading || !booted);

  // golden finale scrub — owned here because it spans gallery -> overlay
  useGSAP(
    () => {
      if (!dataReady || !booted) return;
      gsap.set(outroRef.current, { autoAlpha: 0 });
      gsap.to(outroRef.current, {
        autoAlpha: 1,
        ease: 'none',
        scrollTrigger: {
          trigger: gallerySectionRef.current,
          start: 'bottom bottom+=100%',
          end: 'bottom bottom',
          scrub: 0.6,
          onUpdate: (self) => {
            setOutroVisible(self.progress > 0.5);
            setOutroActive(self.progress > 0.9);
          },
        },
      });
    },
    { scope: rootRef, dependencies: [dataReady, booted, isMobile] }
  );

  // ------------------------------------------------------------ navigation
  const scrollToTop = useCallback(() => window.scrollTo({ top: 0, behavior: 'smooth' }), []);

  const scrollToGallery = useCallback(() => {
    const el = gallerySectionRef.current;
    window.scrollTo({ top: el ? el.offsetTop : window.innerHeight * 2, behavior: 'smooth' });
  }, []);

  const scrollToEnd = useCallback(() => {
    window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
  }, []);

  // ---------------------------------------------------------------- render
  return (
    <div ref={rootRef} className="min-h-screen bg-ink text-cream">
      <CustomCursor />
      <ScrollProgress />

      <AnimatePresence>{showLoader && <Loader />}</AnimatePresence>

      {error && !loading && (
        <div className="fixed inset-0 z-[90] flex flex-col items-center justify-center gap-5 bg-ink px-6 text-center">
          <div className="font-display text-2xl uppercase tracking-[0.3em] text-cream">Monarch</div>
          <p className="max-w-xs text-[11px] uppercase tracking-[0.25em] text-cream/50">
            the empire couldn't load — {error}
          </p>
          <button
            onClick={load}
            data-cursor
            className="mt-2 border border-gold/50 px-9 py-3 text-[11px] uppercase tracking-[0.3em] text-gold transition-colors hover:bg-gold hover:text-ink"
          >
            retry
          </button>
        </div>
      )}

      {dataReady && booted && brand && (
        <main>
          <Hero
            brand={brand}
            lookCount={items.length}
            onScrollToTop={scrollToTop}
            onScrollToGallery={scrollToGallery}
            onScrollToEnd={scrollToEnd}
          />
          <Ticker items={ticker} />
          <Manifesto lines={manifesto} alias={brand.alias} />
          <About content={aboutContent} facts={aboutFacts} />
          <Stats stats={stats} />
          <Services services={services} />
          <Method steps={steps} services={services} brand={brand} />
          <Gallery items={items} isMobile={isMobile} sectionRef={gallerySectionRef} />
          <Outro
            overlayRef={outroRef}
            visible={outroVisible}
            active={outroActive}
            brand={brand}
            lookCount={items.length}
            onCta={scrollToTop}
          />
        </main>
      )}
    </div>
  );
}
