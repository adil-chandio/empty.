import type {
  AboutPayload,
  BrandHero,
  GalleryItem,
  ManifestoLine,
  MethodStep,
  Service,
  Stat,
  TickerItem,
} from './types';

async function get<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`${path} failed (${res.status})`);
  return res.json();
}

export const fetchBrand = () => get<BrandHero>('/api/brand');
export const fetchStats = () => get<Stat[]>('/api/stats');
export const fetchServices = () => get<Service[]>('/api/services');
export const fetchTicker = () => get<TickerItem[]>('/api/ticker');
export const fetchManifesto = () => get<ManifestoLine[]>('/api/manifesto');
export const fetchMethod = () => get<MethodStep[]>('/api/method');
export const fetchAbout = () => get<AboutPayload>('/api/about');
export const fetchGallery = () => get<GalleryItem[]>('/api/gallery');
