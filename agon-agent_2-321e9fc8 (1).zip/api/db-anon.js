import { createClient } from '@supabase/supabase-js';
import { triggerRestore } from './db-wake.js';

// Public-content client: uses the anon key (service-role key is not registered
// for this project). Same 5xx resilience/restore behavior as db-client.js.
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  {
    global: {
      fetch: async (url, options) => {
        const res = await fetch(url, options);
        if (!res.ok && res.status >= 500) triggerRestore();
        return res;
      },
    },
  }
);

export default supabase;
