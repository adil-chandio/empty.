import supabase from './db-anon.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const [contentRes, factsRes] = await Promise.all([
        supabase.from('about_content').select('*').order('id', { ascending: true }),
        supabase.from('about_facts').select('*').order('id', { ascending: true }),
      ]);
      if (contentRes.error) throw contentRes.error;
      if (factsRes.error) throw factsRes.error;
      return res.status(200).json({ content: contentRes.data, facts: factsRes.data });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
